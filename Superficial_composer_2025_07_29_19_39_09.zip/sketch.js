function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
// Definindo variáveis globais 
let jardineiro;
let plantas = [];
let temperatura = 10;
let totalArvores = 0;